# Load required package
library(tidyverse)
library(data.table)
library(readr)
library(reshape2)
library(lubridate)
library(geosphere)
library(rpart.plot)
library(caret)
library(rpart)
library(randomForest)

# Load the data set
fraudTrain <- read_csv("C:/Users/ASUS/OneDrive/Desktop/Msc Project/In/Dataset_1_fraudTrain.csv", show_col_types = FALSE)
fraudTest <- read_csv("C:/Users/ASUS/OneDrive/Desktop/Msc Project/In/Dataset_1_fraudTest.csv", show_col_types = FALSE)




############-------------------Resampling training & test sets--------------############

# Data was pre-split by date. Merging together to randomly split. Must first remove X1 row number to prevent duplicates.
fraudTest <- fraudTest[-1]
fraudTrain <- fraudTrain[-1]
fraudSet <- rbind(fraudTrain, fraudTest)

# removing pre-split sets
rm(fraudTest, fraudTrain)

# summary of data
summary(fraudSet)


# Exploring data set variables & structure
glimpse(fraudSet)


# Creating Random Sampling of Training & 20% Final Test set of fraud data. 
set.seed(1, sample.kind="Rounding") 
test_index <- createDataPartition(y = fraudSet$is_fraud, times = 1, p = 0.2, list = FALSE)
train_set <- fraudSet[-test_index,]
test_set <- fraudSet[test_index,]


# summary of training and test data
summary(train_set)
summary(test_set)

# proportion of fraudulent transactions
prop.table(table(train_set$is_fraud))
prop.table(table(test_set$is_fraud))


# date ranges for provided train and test sets 
range(train_set$trans_date_trans_time)
range(test_set$trans_date_trans_time)


# Fraud vs legitimate average transaction amounts & # trans
train_set %>% group_by(is_fraud) %>% summarize(avg_trans = mean(amt), med_trans = median(amt))

train_set %>% group_by(is_fraud) %>% summarize(amt = sum(amt), n = n()) %>% mutate(pct_amt = (amt/sum(amt))*100, pct_n = (n/sum(n))*100)





#################-----------EDA-----------#################



# Summary of Bins by Fraud
train_set %>% mutate(bins = cut(amt, breaks = c(-Inf, 100, 1000, Inf), labels = c("<$100","$100-$999","$1K+"))) %>%
  group_by(bins, is_fraud) %>% summarize(amt = sum(amt), n = n())  %>% mutate(pct_amt = (amt/sum(amt))*100)

# Distributions of Transaction Amounts
train_set %>% filter(is_fraud == 0) %>% mutate(bins = cut(amt, breaks = c(-Inf, 100, 1000, Inf), labels = c("<$100","$100-$999","$1K+"))) %>%
  ggplot(aes(amt)) + geom_histogram(bins = 40, fill = "green") + 
  theme_bw(base_size = 10) + ggtitle("Legitimate Transaction Amounts ($s)") +
  facet_wrap(~ bins, scales = "free")

# Distributions of Fraud Transaction Amounts
train_set %>% filter(is_fraud == 1) %>% mutate(bins = cut(amt, breaks = c(-Inf, 100, 1000, Inf), labels = c("<$100","$100-$999","$1K+"))) %>%
  ggplot(aes(amt)) + geom_histogram(bins = 40, fill = "red") + 
  theme_bw(base_size = 10) + ggtitle("Fraudulent Transaction Amounts ($s)") +
  facet_wrap(~ bins, scales = "free")



# Barchart with Fraud & Legit sales by category $s
train_set %>% group_by(category, is_fraud) %>% summarize(amt = sum(amt), n = n()) %>%
  ggplot(aes(x = amt,y = reorder(category,amt), fill = as.factor(is_fraud))) +
  geom_bar(stat = "identity") + labs(x="Transaction Amount", y="") + scale_fill_manual(values=c("grey64","darkblue")) +
  theme_bw(base_size = 10) + scale_x_continuous(labels = comma) +  theme(legend.position = "bottom") +
  ggtitle("Sales Category Fraud") 


# (Grid) Fraud & Legit Breakdown per category by % Amount 
train_set %>% mutate(bins = cut(amt, breaks =  c(-Inf, 100, 250, 800, 1400, Inf), labels = c("<$100","$100-$249","$250-$799","$800-$1399","$1.4K+"))) %>% 
  group_by(is_fraud,category,bins) %>% summarize(amt = sum(amt)) %>% mutate(pct_amt = (amt/sum(amt))) %>%
  ggplot(aes(x = pct_amt,y = reorder(category,pct_amt), fill = as.factor(is_fraud))) +
  geom_col(position = position_dodge2(width = 0.9, preserve = "single")) + labs(x="Transaction Amount", y="") + 
  theme_bw(base_size = 10) + scale_x_continuous(labels = comma) + scale_fill_manual(values=c("grey68","skyblue")) +
  theme(legend.position = "bottom",panel.grid.minor = element_blank()) + 
  ggtitle("Fraud Transaction Amounts by Category") + facet_grid(~bins)



### Repeat Fraud ### 

# Repeat fraud by CC
repeat_cc <- train_set %>% filter(is_fraud ==1) %>% group_by(cc_num) %>% 
  summarize(total = sum(amt), avg = mean(amt), n = n()) %>% 
  ggplot(aes(n)) + geom_histogram(bins = 20,fill = "56B4E9") + 
  theme_bw(base_size = 9) + theme(axis.title=element_blank()) + ggtitle("Number of Fraud Transactions on Same Credit Card")

# Repeat fraud by Merchant
repeat_merc <- train_set %>% filter(is_fraud ==1) %>% group_by(merchant) %>% 
  summarize(total = sum(amt), avg = mean(amt), n = n()) %>%
  ggplot(aes(n)) + geom_histogram(bins = 40,fill = "56B4E9") + 
  theme_bw(base_size = 9) + theme(axis.title=element_blank()) + ggtitle("Number of Fraud Transactions Same Merchant")

grid.arrange(repeat_cc, repeat_merc, ncol = 2)

rm(repeat_cc, repeat_merc)




## by Distance to Merchant

# Calculate distance between cust & merchant with longitude and latitude . This takes several minutes. 
train_distance <- train_set[c(1:5,12:14,20:22)] %>% rowwise() %>% mutate(trans_dist = distHaversine(c(long, lat),c(merch_long, merch_lat))/ 1609)

range(train_distance$trans_dist)

train_distance %>% 
  ggplot(aes(trans_dist)) + geom_histogram(bins = 40, fill = "56B4E9") + labs(x="Miles between Customer / Merchant ", y="") +
  theme_bw(base_size = 10) + ggtitle("Transaction Distances") + facet_wrap(~is_fraud, scales = "free")


### by State ###


# Breakdown/Percent Fraud Sales $s by State. Small pop states have large % of their sales as fraud.  
st_f <- train_set %>% group_by(is_fraud, state) %>% summarize(amt = sum(amt), n = n()) %>% 
  mutate(pct_amt = (amt/sum(amt))*100, pct_n = (n/sum(n))*100) %>% filter(is_fraud ==1) %>% 
  ggplot(aes(x=pct_amt, y = reorder(state, pct_amt), label = round(pct_amt, digits = 1))) + xlim(0,20) +
  geom_bar(stat = "identity", fill = "slategrey") + geom_text(size = 3, nudge_x = .8, alpha = 1/2) + 
  theme_bw(base_size = 9) + theme(axis.title.x=element_blank(), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank()) + 
  ggtitle("Percent Fraud $s by State")

# Breakdown/Percent Accounts by State
st_a <- train_set %>% group_by(state) %>% summarize(accts = n_distinct(cc_num), amt = sum(amt), n = n()) %>% 
  mutate(pct_accts = (accts/sum(accts))*100) %>%
  ggplot(aes(x=pct_accts, y = reorder(state, pct_accts), label = round(pct_accts, digits = 1))) + xlim(0,20) +
  geom_bar(stat = "identity", fill = "slategrey") + geom_text(size = 3, nudge_x = .8, alpha = 1/2) + 
  theme_bw(base_size = 9) + theme(axis.title.x=element_blank(), panel.grid.major.y = element_blank(), panel.grid.minor = element_blank()) + 
  ggtitle("Accounts by State")

grid.arrange(st_f, st_a, ncol = 2)

rm(st_f, st_a)

### Transactions by Gender ###  

# fraud by gender
train_set %>% group_by(is_fraud, gender) %>% summarize(amt = sum(amt), n = n()) %>% 
  mutate(pct_amt = amt/sum(amt), pct_n = n/sum(n)) %>% filter(is_fraud ==1)


# Percent Fraud Sales $s by State. Small pop states have large % of their sales as fraud.  
train_set %>% group_by(state, is_fraud) %>% summarize(amt = sum(amt), n = n()) %>% 
  mutate(pct_amt = (amt/sum(amt))*100, pct_n = (n/sum(n))*100) %>% filter(is_fraud ==1 & pct_amt > 5) %>%
  ggplot(aes(x=pct_amt,  y = reorder(state, pct_amt), label = round(pct_amt, digits = 1))) + 
  geom_bar(stat = "identity", fill = "slategrey") + geom_text(size = 3, nudge_x = 2) + labs(x = "", y = "") +
  theme_bw(base_size = 10) + ggtitle("States with Highest Percentage Fraud Amounts")



############---------correlation matrix-------#######

# Convert categorical variables to numeric (if applicable)
df_encoded <- fraudSet %>%
  mutate(across(where(is.factor), as.numeric))

# Ensure all columns are numeric for correlation analysis
df_numeric <- df_encoded %>%
  select(where(is.numeric))

# Calculate the Pearson correlation matrix
correlation_matrix <- cor(df_numeric, use = "complete.obs", method = "pearson")

# Print the correlation matrix
print(correlation_matrix)

# Function to get the lower triangle of the correlation matrix
get_lower_tri <- function(cormat){
  cormat[upper.tri(cormat, diag = TRUE)] <- NA
  return(cormat)
}

# Get the lower triangle of the correlation matrix
lower_tri <- get_lower_tri(correlation_matrix)

# Melt the lower triangle of the correlation matrix
correlation_melted <- melt(lower_tri, na.rm = TRUE)

# Plot the heatmap
ggplot(correlation_melted, aes(x = Var2, y = Var1, fill = value)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1, 1), space = "Lab", 
                       name = "Pearson\nCorrelation") +
  theme_minimal() +
  labs(x = '', y = '', title = 'Correlation Heatmap') +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1)) +
  coord_fixed() +
  geom_text(aes(label = round(value, 2)), color = "black", size = 3)



######-----Model Building----##########

######-----Prepared data for Rpart Model----##########


# 'fraudSet' is my dataset 1

df <- fraudSet

# Convert date and time elements into features
df <- df %>%
  mutate(trans_date_trans_time = as.POSIXct(trans_date_trans_time, format = "%m/%d/%Y %H:%M"),
         trans_hour = as.factor(format(trans_date_trans_time, "%H")),
         trans_day = as.factor(format(trans_date_trans_time, "%d")),
         trans_month = as.factor(format(trans_date_trans_time, "%m")),
         trans_weekday = as.factor(format(trans_date_trans_time, "%u"))) %>%
  select(-trans_date_trans_time)

# Convert cc_num to character
df$cc_num <- as.character(df$cc_num)

# Define train and test sets
set.seed(123)
trainIndex <- createDataPartition(df$is_fraud, p = .9, list = FALSE, times = 1)
train2 <- df[ trainIndex,]
test2  <- df[-trainIndex,]

# Ensure the is_fraud column is a factor in both train and test datasets
train2$is_fraud <- as.factor(train2$is_fraud)
test2$is_fraud <- as.factor(test2$is_fraud)



# Rpart Model 1
formula1 <- is_fraud ~ amt + category + trans_hour + trans_day + trans_month + trans_weekday + merchant + cc_num
rpart_model1 <- rpart(formula1, data = train2, method = "class")

# Predict and ensure predictions are factors with the same levels as the actual values
pred_rpart1 <- predict(rpart_model1, test2, type = "class")
pred_rpart1 <- factor(pred_rpart1, levels = levels(test2$is_fraud))

# Confusion Matrix for Rpart Model 1
conf_matrix_rpart1 <- confusionMatrix(pred_rpart1, test2$is_fraud)
print(conf_matrix_rpart1)

# Calculate metrics
pred_prob_rpart1 <- predict(rpart_model1, test2, type = "prob")[,2]
test2$predicted_rpart1 <- ifelse(pred_prob_rpart1 > 0.5, 1, 0)
Model_AmtSaved <- sum(test2$amt[test2$is_fraud == 1 & test2$predicted_rpart1 == 1])
FraudMissed <- sum(test2$amt[test2$is_fraud == 1 & test2$predicted_rpart1 == 0])
MisClassified <- sum(test2$is_fraud != test2$predicted_rpart1)
SavedPct <- Model_AmtSaved / sum(test2$amt[test2$is_fraud == 1])
MisClassPct <- MisClassified / nrow(test2)
Specificity <- conf_matrix_rpart1$byClass["Specificity"]
NPV <- conf_matrix_rpart1$byClass["Neg Pred Value"]

# Rpart Model 1 Results
results_rpart1 <- data.frame(
  Model = "Rpart All Vars",
  AmtSaved = Model_AmtSaved,
  FraudMissed = FraudMissed,
  MisClassified = MisClassified,
  SavedPct = SavedPct,
  MisClassPct = MisClassPct,
  Specificity = Specificity,
  NPV = NPV
)
print(results_rpart1)

# Variable Importance for Rpart Model 1
var_importance_rpart1 <- as.data.frame(varImp(rpart_model1))
print(var_importance_rpart1)



# Rpart Model 2: Basic model
formula2 <- is_fraud ~ amt + category + trans_hour + trans_month + trans_day + trans_weekday
rpart_model2 <- rpart(formula2, data = train2, method = "class")

# Predict and ensure predictions are factors with the same levels as the actual values
pred_rpart2 <- predict(rpart_model2, test2, type = "class")
pred_rpart2 <- factor(pred_rpart2, levels = levels(test2$is_fraud))

# Confusion Matrix for Rpart Model 2
conf_matrix_rpart2 <- confusionMatrix(pred_rpart2, test2$is_fraud)
print(conf_matrix_rpart2)





# Rpart Model 3: Including cc_num
formula3 <- is_fraud ~ amt + category + trans_hour + trans_month + trans_day + trans_weekday + cc_num
rpart_model3 <- rpart(formula3, data = train2, method = "class")

# Predict and ensure predictions are factors with the same levels as the actual values
pred_rpart3 <- predict(rpart_model3, test2, type = "class")
pred_rpart3 <- factor(pred_rpart3, levels = levels(test2$is_fraud))

# Confusion Matrix for Rpart Model 3
conf_matrix_rpart3 <- confusionMatrix(pred_rpart3, test2$is_fraud)
print(conf_matrix_rpart3)


# Helper function to calculate metrics
calculate_metrics <- function(model, test_data, predictions, conf_matrix) {
  pred_prob <- predict(model, test_data, type = "prob")[,2]
  test_data$predicted <- ifelse(pred_prob > 0.5, 1, 0)
  amt_saved <- sum(test_data$amt[test_data$is_fraud == 1 & test_data$predicted == 1])
  fraud_missed <- sum(test_data$amt[test_data$is_fraud == 1 & test_data$predicted == 0])
  misclassified <- sum(test_data$is_fraud != test_data$predicted)
  saved_pct <- amt_saved / sum(test_data$amt[test_data$is_fraud == 1])
  misclass_pct <- misclassified / nrow(test_data)
  specificity <- conf_matrix$byClass["Specificity"]
  npv <- conf_matrix$byClass["Neg Pred Value"]
  
  data.frame(
    Model = deparse(substitute(model)),
    AmtSaved = amt_saved,
    FraudMissed = fraud_missed,
    MisClassified = misclassified,
    SavedPct = saved_pct,
    MisClassPct = misclass_pct,
    Specificity = specificity,
    NPV = npv
  )
}

# Calculate metrics for each model
results_rpart1 <- calculate_metrics(rpart_model1, test2, pred_rpart1, conf_matrix_rpart1)
results_rpart2 <- calculate_metrics(rpart_model2, test2, pred_rpart2, conf_matrix_rpart2)
results_rpart3 <- calculate_metrics(rpart_model3, test2, pred_rpart3, conf_matrix_rpart3)


# Combine the results into a single data frame for comparison
results_combined <- rbind(results_rpart1, results_rpart2, results_rpart3)



# Create a table for easier comparison in the report
results_table <- results_combined %>%
  select(Model, AmtSaved, FraudMissed, MisClassified, SavedPct, MisClassPct, Specificity, NPV) %>%
  mutate(AmtSaved = round(AmtSaved, 2),
         FraudMissed = round(FraudMissed, 2),
         MisClassified = round(MisClassified, 2),
         SavedPct = round(SavedPct * 100, 2),
         MisClassPct = round(MisClassPct * 100, 2),
         Specificity = round(Specificity * 100, 2),
         NPV = round(NPV * 100, 2))

# Print the results table
print(results_table)



# Convert results_combined to long format for ggplot
results_long <- results_combined %>%
  gather(key = "Metric", value = "Value", -Model)

# Plot
ggplot(results_long, aes(x = Model, y = Value, fill = Metric)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  theme_minimal() +
  labs(title = "Comparison of Rpart Models",
       x = "Model",
       y = "Value",
       fill = "Metric") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



######-----Prepared data for Logistic Regression glm Model----##########

# 'fraudSet' is your dataset
df <- fraudSet


# Convert date and time elements into features
df <- df %>%
  mutate(trans_date_trans_time = as.POSIXct(trans_date_trans_time, format = "%m/%d/%Y %H:%M"),
         trans_hour = as.factor(format(trans_date_trans_time, "%H")),
         trans_day = as.factor(format(trans_date_trans_time, "%d")),
         trans_month = as.factor(format(trans_date_trans_time, "%m")),
         trans_weekday = as.factor(format(trans_date_trans_time, "%u")),
         bins = cut(amt, breaks = c(-Inf, 100, 1000, Inf), labels = c("<$100", "$100-$999", "$1K+"))) %>%
  select(-trans_date_trans_time)

# Convert cc_num to character
df$cc_num <- as.character(df$cc_num)

# Define train and test sets
set.seed(123)
trainIndex <- createDataPartition(df$is_fraud, p = .9, 
                                  list = FALSE, 
                                  times = 1)
train2 <- df[ trainIndex,]
test2  <- df[-trainIndex,]

# Ensure the is_fraud column is a factor in both train and test datasets
train2$is_fraud <- as.factor(train2$is_fraud)
test2$is_fraud <- as.factor(test2$is_fraud)


# GLM Model 1 with the correct formula
formula1 <- is_fraud ~ amt * category + trans_hour + trans_month + trans_day + trans_weekday
glm_model1 <- glm(formula1, data = train2, family = binomial)
pred_glm1 <- predict(glm_model1, test2, type = "response")
pred_class_glm1 <- ifelse(pred_glm1 > 0.5, 1, 0)
pred_class_glm1 <- factor(pred_class_glm1, levels = levels(test2$is_fraud))

# Confusion Matrix for GLM Model 1
conf_matrix_glm1 <- confusionMatrix(pred_class_glm1, test2$is_fraud)
print(conf_matrix_glm1)

# Calculate metrics
Model_AmtSaved_glm1 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm1 == 1], na.rm = TRUE)
FraudMissed_glm1 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm1 == 0], na.rm = TRUE)
MisClassified_glm1 <- sum(test2$is_fraud != pred_class_glm1, na.rm = TRUE)
SavedPct_glm1 <- Model_AmtSaved_glm1 / sum(test2$amt[test2$is_fraud == 1], na.rm = TRUE)
MisClassPct_glm1 <- MisClassified_glm1 / nrow(test2)
Specificity_glm1 <- conf_matrix_glm1$byClass["Specificity"]
NPV_glm1 <- conf_matrix_glm1$byClass["Neg Pred Value"]

# GLM Model 1 Results
results_glm1 <- data.frame(
  Model = "GLM cat*amt",
  AmtSaved = Model_AmtSaved_glm1,
  FraudMissed = FraudMissed_glm1,
  MisClassified = MisClassified_glm1,
  SavedPct = SavedPct_glm1,
  MisClassPct = MisClassPct_glm1,
  Specificity = Specificity_glm1,
  NPV = NPV_glm1
)
print(results_glm1)


# GLM Model 2
glm_model2 <- glm(is_fraud ~ amt + category+ bins + trans_hour + trans_month + trans_day + trans_weekday, data = train2, family = "binomial")


# Predict and ensure predictions are factors with the same levels as the actual values
pred_prob_glm2 <- predict(glm_model2, test2, type = "response")
pred_class_glm2 <- ifelse(pred_prob_glm2 > 0.5, 1, 0)
pred_class_glm2 <- factor(pred_class_glm2, levels = levels(test2$is_fraud))

# Confusion Matrix for GLM Model 2
conf_matrix_glm2 <- confusionMatrix(pred_class_glm2, test2$is_fraud)
print(conf_matrix_glm2)

# Calculate metrics
Model_AmtSaved_glm2 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm2 == 1], na.rm = TRUE)
FraudMissed_glm2 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm2 == 0], na.rm = TRUE)
MisClassified_glm2 <- sum(test2$is_fraud != pred_class_glm2, na.rm = TRUE)
SavedPct_glm2 <- Model_AmtSaved_glm2 / sum(test2$amt[test2$is_fraud == 1], na.rm = TRUE)
MisClassPct_glm2 <- MisClassified_glm2 / nrow(test2)
Specificity_glm2 <- conf_matrix_glm2$byClass["Specificity"]
NPV_glm2 <- conf_matrix_glm2$byClass["Neg Pred Value"]

# GLM Model 2 Results
results_glm2 <- data.frame(
  Model = "GLM cat+amt+bins",
  AmtSaved = Model_AmtSaved_glm2,
  FraudMissed = FraudMissed_glm2,
  MisClassified = MisClassified_glm2,
  SavedPct = SavedPct_glm2,
  MisClassPct = MisClassPct_glm2,
  Specificity = Specificity_glm2,
  NPV = NPV_glm2
)
print(results_glm2)



# GLM Model 3
glm_model3 <- glm(is_fraud ~ amt * category * bins + trans_hour + trans_month + trans_day + trans_weekday, data = train2, family = "binomial")

# Predict and ensure predictions are factors with the same levels as the actual values
pred_prob_glm3 <- predict(glm_model3, test2, type = "response")
pred_class_glm3 <- ifelse(pred_prob_glm3 > 0.5, 1, 0)
pred_class_glm3 <- factor(pred_class_glm3, levels = levels(test2$is_fraud))

# Confusion Matrix for GLM Model 3
conf_matrix_glm3 <- confusionMatrix(pred_class_glm3, test2$is_fraud)
print(conf_matrix_glm3)

# Calculate metrics
Model_AmtSaved_glm3 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm3 == 1], na.rm = TRUE)
FraudMissed_glm3 <- sum(test2$amt[test2$is_fraud == 1 & pred_class_glm3 == 0], na.rm = TRUE)
MisClassified_glm3 <- sum(test2$is_fraud != pred_class_glm3, na.rm = TRUE)
SavedPct_glm3 <- Model_AmtSaved_glm3 / sum(test2$amt[test2$is_fraud == 1], na.rm = TRUE)
MisClassPct_glm3 <- MisClassified_glm3 / nrow(test2)
Specificity_glm3 <- conf_matrix_glm3$byClass["Specificity"]
NPV_glm3 <- conf_matrix_glm3$byClass["Neg Pred Value"]

# GLM Model 3 Results
results_glm3 <- data.frame(
  Model = "GLM cat*amt*bins",
  AmtSaved = Model_AmtSaved_glm3,
  FraudMissed = FraudMissed_glm3,
  MisClassified = MisClassified_glm3,
  SavedPct = SavedPct_glm3,
  MisClassPct = MisClassPct_glm3,
  Specificity = Specificity_glm3,
  NPV = NPV_glm3
)
print(results_glm3)


# Combine results for comparison
results_combined <- rbind(
  results_glm1,
  results_glm2,
  results_glm3
)


# Create a table for easier comparison in the report
results_table <- results_combined %>%
  select(Model, AmtSaved, FraudMissed, MisClassified, SavedPct, MisClassPct, Specificity, NPV) %>%
  mutate(AmtSaved = round(AmtSaved, 2),
         FraudMissed = round(FraudMissed, 2),
         MisClassified = round(MisClassified, 2),
         SavedPct = round(SavedPct * 100, 2),
         MisClassPct = round(MisClassPct * 100, 2),
         Specificity = round(Specificity * 100, 2),
         NPV = round(NPV * 100, 2))

# Print the results table
print(results_table)



# Convert results_combined to long format for ggplot
results_long <- results_combined %>%
  gather(key = "Metric", value = "Value", -Model)

# Plot
ggplot(results_long, aes(x = Model, y = Value, fill = Metric)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  theme_minimal() +
  labs(title = "Comparison of GLM Models",
       x = "Model",
       y = "Value",
       fill = "Metric") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


######-----Prepared data for RandomForest Model----##########

#'fraudSet' is your dataset

df <- fraudSet

# Convert date and time elements into features
df <- df %>%
  mutate(trans_date_trans_time = as.POSIXct(trans_date_trans_time, format = "%m/%d/%Y %H:%M"),
         trans_hour = as.factor(format(trans_date_trans_time, "%H")),
         trans_day = as.factor(format(trans_date_trans_time, "%d")),
         trans_month = as.factor(format(trans_date_trans_time, "%m")),
         trans_weekday = as.factor(format(trans_date_trans_time, "%u"))) %>%
  select(-trans_date_trans_time)

# Exclude high cardinality variables
df <- df %>%
  select(-merchant, -cc_num)

# Convert categorical variables to factors
df <- df %>%
  mutate(across(where(is.character), as.factor))


# Remove high-cardinality variables from the dataset
df <- df %>%
  select(-first, -last, -street, -city, -job, -dob, -trans_num, -zip)

# Convert any remaining categorical variables to factors
df <- df %>%
  mutate(across(where(is.character), as.factor))

# Handle any missing values by removing or imputing them
df <- na.omit(df)  

# Ensure 'is_fraud' is a factor
df$is_fraud <- as.factor(df$is_fraud)

# Recheck for any remaining high-cardinality variables
sapply(df, function(x) if(is.factor(x)) length(unique(x)) else NA)


# Split the dataset into training and testing sets
set.seed(123)
trainIndex <- createDataPartition(df$is_fraud, p = .8, list = FALSE, times = 1)
train2 <- df[trainIndex, ]
test2  <- df[-trainIndex, ]


# Model 1: Random Forest with 51 trees
rf_model1 <- randomForest(is_fraud ~ ., data = train2, ntree = 70, replacement = TRUE, importance = TRUE)

# Predict using the model
pred_rf1 <- predict(rf_model1, test2)

# Evaluate the model using a confusion matrix
conf_matrix_rf1 <- confusionMatrix(pred_rf1, test2$is_fraud)
print(conf_matrix_rf1)


# Extract metrics from the confusion matrix
Model_AmtSaved_rf1 <- sum(test2$amt[test2$is_fraud == 1 & pred_rf1 == 1], na.rm = TRUE)
FraudMissed_rf1 <- sum(test2$amt[test2$is_fraud == 1 & pred_rf1 == 0], na.rm = TRUE)
MisClassified_rf1 <- sum(test2$is_fraud != pred_rf1, na.rm = TRUE)
SavedPct_rf1 <- Model_AmtSaved_rf1 / sum(test2$amt[test2$is_fraud == 1], na.rm = TRUE)
MisClassPct_rf1 <- MisClassified_rf1 / nrow(test2)
Specificity_rf1 <- conf_matrix_rf1$byClass["Specificity"]
NPV_rf1 <- conf_matrix_rf1$byClass["Neg Pred Value"]

# Combine the metrics into a data frame for easy comparison
results_rf1 <- data.frame(
  Model = "Random Forest Model 1",
  AmtSaved = Model_AmtSaved_rf1,
  FraudMissed = FraudMissed_rf1,
  MisClassified = MisClassified_rf1,
  SavedPct = SavedPct_rf1,
  MisClassPct = MisClassPct_rf1,
  Specificity = Specificity_rf1,
  NPV = NPV_rf1
)

print(results_rf1)


# Display variable importance
importance_rf1 <- importance(rf_model1)
varImpPlot(rf_model1)


# Model 2: Random Forest with 251 trees
rf_model2 <- randomForest(is_fraud ~ ., data = train2, ntree = 140, replacement = TRUE, importance = TRUE)

# Predict using the model
pred_rf2 <- predict(rf_model2, test2)

# Evaluate the model using a confusion matrix
conf_matrix_rf2 <- confusionMatrix(pred_rf2, test2$is_fraud)
print(conf_matrix_rf2)


# Extract metrics from the confusion matrix
Model_AmtSaved_rf2 <- sum(test2$amt[test2$is_fraud == 1 & pred_rf2 == 1], na.rm = TRUE)
FraudMissed_rf2 <- sum(test2$amt[test2$is_fraud == 1 & pred_rf2 == 0], na.rm = TRUE)
MisClassified_rf2 <- sum(test2$is_fraud != pred_rf2, na.rm = TRUE)
SavedPct_rf2 <- Model_AmtSaved_rf2 / sum(test2$amt[test2$is_fraud == 1], na.rm = TRUE)
MisClassPct_rf2 <- MisClassified_rf2 / nrow(test2)
Specificity_rf2 <- conf_matrix_rf2$byClass["Specificity"]
NPV_rf2 <- conf_matrix_rf2$byClass["Neg Pred Value"]

# Combine the metrics into a data frame for easy comparison
results_rf2 <- data.frame(
  Model = "Random Forest Model 2",
  AmtSaved = Model_AmtSaved_rf2,
  FraudMissed = FraudMissed_rf2,
  MisClassified = MisClassified_rf2,
  SavedPct = SavedPct_rf2,
  MisClassPct = MisClassPct_rf2,
  Specificity = Specificity_rf2,
  NPV = NPV_rf2
)

# Print the results for Random Forest Model 2
print(results_rf2)


# Display variable importance
importance_rf2 <- importance(rf_model2)
varImpPlot(rf_model2)

# First, add model names as a new column
results_rf1$Model <- "Random Forest Model 1"
results_rf2$Model <- "Random Forest Model 2"


# Combine results for comparison
results_combined <- rbind(results_rf1, results_rf2)
print(results_combined)

# Melt the data frame for easier plotting
results_melted <- reshape2::melt(results_combined, id.vars = "Model")

# Create the bar chart
ggplot(results_melted, aes(x = variable, y = value, fill = Model)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Comparison of Random Forest Models", x = "Metrics", y = "Values") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
