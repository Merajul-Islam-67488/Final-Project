# Load required package
library(tidyverse)
library(data.table)
library(reshape2)
library(geosphere)
library(rpart.plot)
library(caret)
library(rpart)
library(randomForest)
library(ggmap)
library(ggcorrplot)
library(GGally)
library(ggcorrplot)
library(ggmap)
library(pROC)
library(MASS)



# Load the data set
data <- read_csv("C:/Users/ASUS/OneDrive/Desktop/Msc Project/In/Dataset_2.csv", show_col_types = FALSE)

# Remove rows with missing values
data <- na.omit(data)


#summary of dataset
summary(data)


# Exploring data set variables & structure
glimpse(data)


# Creating Random Sampling of Training & 20% Final Test set of fraud data. 
set.seed(1, sample.kind="Rounding") 
test_index <- createDataPartition(y = data$fraud, times = 1, p = 0.2, list = FALSE)
train_set <- data[-test_index,]
test_set <- data[test_index,]



# summary of training and test data

summary(train_set)
summary(test_set)

# proportion of fraudulent transactions
prop.table(table(train_set$fraud))
prop.table(table(test_set$fraud))


# Calculate average transaction amounts and number of transactions for fraud vs legitimate
fraud_vs_legitimate <- data %>%
  group_by(fraud) %>%
  summarise(
    average_distance_from_home = mean(distance_from_home, na.rm = TRUE),
    average_distance_from_last_transaction = mean(distance_from_last_transaction, na.rm = TRUE),
    average_ratio_to_median_purchase_price = mean(ratio_to_median_purchase_price, na.rm = TRUE),
    transaction_count = n()
  )

# Print the summary
print(fraud_vs_legitimate)




################----EDA----####################




# Transaction Amount Distribution
ggplot(data, aes(x = ratio_to_median_purchase_price, fill = as.factor(fraud))) +
  geom_histogram(position = "dodge", bins = 30) +
  labs(title = "Transaction Amount Distribution", x = "Ratio to Median Purchase Price", fill = "Fraud") +
  theme_minimal()

# Distance from Home Distribution
ggplot(data, aes(x = distance_from_home, fill = as.factor(fraud))) +
  geom_histogram(position = "dodge", bins = 30) +
  labs(title = "Distance from Home Distribution", x = "Distance from Home", fill = "Fraud") +
  theme_minimal()


# Distance from Last Transaction Distribution
ggplot(data, aes(x = distance_from_last_transaction, fill = as.factor(fraud))) +
  geom_histogram(position = "dodge", bins = 30) +
  labs(title = "Distance from Last Transaction Distribution", x = "Distance from Last Transaction", fill = "Fraud") +
  theme_minimal()

# Categorical Variables Analysis
categorical_vars <- c("repeat_retailer", "used_chip", "used_pin_number", "online_order")
for (var in categorical_vars) {
  print(
    ggplot(data, aes_string(x = var, fill = "as.factor(fraud)")) +
      geom_bar(position = "dodge") +
      labs(title = paste("Distribution of", var, "by Fraud Status"), x = var, fill = "Fraud") +
      theme_minimal()
  )
}

# Box plots for categorical variables
data %>%
  gather(key = "variable", value = "value", -fraud) %>%
  ggplot(aes(x = as.factor(fraud), y = value)) +
  geom_boxplot() +
  facet_wrap(~variable, scales = "free") +
  labs(title = "Distribution of Variables by Fraud Status", x = "Fraud", y = "Value") +
  theme_minimal()



###########------Correlation Analysis--------#################

# Convert 'fraud' column to numeric for correlation calculation
data$fraud <- as.numeric(data$fraud)

# Convert categorical variables to numeric
data$repeat_retailer <- as.numeric(data$repeat_retailer)
data$used_chip <- as.numeric(data$used_chip)
data$used_pin_number <- as.numeric(data$used_pin_number)
data$online_order <- as.numeric(data$online_order)

# List of continuous variables
continuous_vars <- c("distance_from_home", "distance_from_last_transaction", "ratio_to_median_purchase_price")

# Spearman Correlation for continuous variables
spearman_results_continuous <- sapply(continuous_vars, function(var) {
  cor(data[[var]], data$fraud, method = "spearman")
})

spearman_results_continuous <- data.frame(Variable = continuous_vars, Spearman_Correlation = spearman_results_continuous)

# List of categorical variables
categorical_vars <- c("repeat_retailer", "used_chip", "used_pin_number", "online_order")

# Spearman Correlation for categorical variables
spearman_results_categorical <- sapply(categorical_vars, function(var) {
  cor(data[[var]], data$fraud, method = "spearman")
})
spearman_results_categorical <- data.frame(Variable = categorical_vars, Spearman_Correlation = spearman_results_categorical)

# Combine results
all_spearman_results <- bind_rows(
  spearman_results_continuous %>% mutate(Type = "Continuous"),
  spearman_results_categorical %>% mutate(Type = "Categorical")
)
# Sort by absolute Spearman correlation to find most significant variables
all_spearman_results <- all_spearman_results %>%
  arrange(desc(abs(Spearman_Correlation)))

print(all_spearman_results)


###########------Model Development--------#################


###########------Classification and Regression Trees--------#################


# Model 1: Basic set of predictors
formula1 <- fraud ~ ratio_to_median_purchase_price + online_order
cart_model1 <- rpart(formula1, data = train_set, method = "class")

# Predict and generate confusion matrix
pred_cart1 <- predict(cart_model1, test_set, type = "class")
table(Predicted = pred_cart1, Actual = test_set$fraud)


# Plot the tree
rpart.plot(cart_model1, type = 2, extra = 104, fallen.leaves = TRUE)


# Model 2: Adding more predictors
formula2 <- fraud ~ ratio_to_median_purchase_price + online_order + distance_from_home + distance_from_last_transaction
cart_model2 <- rpart(formula2, data = train_set, method = "class")


# Predict and generate confusion matrix
pred_cart2 <- predict(cart_model2, test_set, type = "class")
table(Predicted = pred_cart2, Actual = test_set$fraud)

# Plot the tree
rpart.plot(cart_model2, type = 2, extra = 104, fallen.leaves = TRUE)



# Model 3: Full set of predictors including used_pin_number
formula3 <- fraud ~ ratio_to_median_purchase_price + online_order + distance_from_home + distance_from_last_transaction + used_pin_number
cart_model3 <- rpart(formula3, data = train_set, method = "class")

# Predict and generate confusion matrix
pred_cart3 <- predict(cart_model3, test_set, type = "class")
table(Predicted = pred_cart3, Actual = test_set$fraud)

# Plot the tree
rpart.plot(cart_model3, type = 2, extra = 104, fallen.leaves = TRUE)


###########------Logistic--------#################


# Model 1: Basic set of predictors
formula1 <- fraud ~ ratio_to_median_purchase_price + online_order
logistic_model1 <- glm(formula1, data = train_set, family = binomial)

# Summary of the model
summary(logistic_model1)



pred1 <- predict(logistic_model1, test_set, type = "response")
roc_curve1 <- roc(test_set$fraud, pred1)
plot(roc_curve1, col = "#1c61b6", main = "ROC Curve for Logistic Regression Model 1")



# Model 2: Adding more predictors
formula2 <- fraud ~ ratio_to_median_purchase_price + online_order + used_pin_number + distance_from_home
logistic_model2 <- glm(formula2, data = train_set, family = binomial)

# Summary of the model
summary(logistic_model2)

# Predict and plot ROC curve
pred2 <- predict(logistic_model2, test_set, type = "response")
roc_curve2 <- roc(test_set$fraud, pred2)
plot(roc_curve2, col = "#1c61b6", main = "ROC Curve for Logistic Regression Model 2")



# Model 3: Full set of predictors including distance_from_last_transaction
formula3 <- fraud ~ ratio_to_median_purchase_price + online_order + used_pin_number + distance_from_home + distance_from_last_transaction
logistic_model3 <- glm(formula3, data = train_set, family = binomial)

# Summary of the model
summary(logistic_model3)

# Predict and plot ROC curve
pred3 <- predict(logistic_model3, test_set, type = "response")
roc_curve3 <- roc(test_set$fraud, pred3)
plot(roc_curve3, col = "#1c61b6", main = "ROC Curve for Logistic Regression Model 3")




###########------Random Forest--------#################

train_set$fraud <- as.factor(train_set$fraud)
test_set$fraud <- as.factor(test_set$fraud)

# Model 1: Basic set of predictors
formula1 <- fraud ~ ratio_to_median_purchase_price + online_order
random_forest_model1 <- randomForest(formula1, data = train_set, ntree = 70, importance = TRUE)

# Summary of the model
print(random_forest_model1)

# Variable importance plot
varImpPlot(random_forest_model1)

# Predict and generate confusion matrix
pred_rf1 <- predict(random_forest_model1, test_set)
table(Predicted = pred_rf1, Actual = test_set$fraud)

# Model 2: Adding more predictors
formula2 <- fraud ~ ratio_to_median_purchase_price + online_order + used_pin_number + distance_from_home
random_forest_model2 <- randomForest(formula2, data = train_set, ntree = 100, importance = TRUE)

# Summary of the model
print(random_forest_model2)

# Variable importance plot
varImpPlot(random_forest_model2)

# Predict and generate confusion matrix
pred_rf2 <- predict(random_forest_model2, test_set)
table(Predicted = pred_rf2, Actual = test_set$fraud)


# Model 3: Full set of predictors including distance_from_last_transaction
formula3 <- fraud ~ ratio_to_median_purchase_price + online_order + used_pin_number + distance_from_home + distance_from_last_transaction
random_forest_model3 <- randomForest(formula3, data = train_set, ntree = 140, importance = TRUE)

# Summary of the model
print(random_forest_model3)

# Variable importance plot
varImpPlot(random_forest_model3)

# Predict and generate confusion matrix
pred_rf3 <- predict(random_forest_model3, test_set)
table(Predicted = pred_rf3, Actual = test_set$fraud)
